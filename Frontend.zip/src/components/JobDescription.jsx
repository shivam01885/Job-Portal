import React, { useEffect, useState } from 'react'
import { Badge } from './ui/badge'
import { Button } from './ui/button'
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { APPLICATION_API_END_POINT, JOB_API_END_POINT } from '@/utils/constant';
import { setSingleJob } from '@/redux/jobSlice';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'sonner';

const JobDescription = () => {
    const {singleJob} = useSelector(store => store.job);
    const {user} = useSelector(store=>store.auth);
    const isIntiallyApplied = singleJob?.applications?.some(application => application.applicant === user?._id) || false;
    const [isApplied, setIsApplied] = useState(isIntiallyApplied);

    const params = useParams();
    const jobId = params.id;
    const dispatch = useDispatch();

    const applyJobHandler = async () => {
        try {
            const res = await axios.get(`${APPLICATION_API_END_POINT}/apply/${jobId}`, {withCredentials:true});
            console.log(res.data);

            if(res.data.success){
                setIsApplied(true);
                const updatedSingleJob = {...singleJob, applications:[...singleJob.applications,{applicant:user?._id}]}
                dispatch(setSingleJob(updatedSingleJob));
                toast.success(res.data.message);
            }
        } catch (error) {
            console.log(error);
            toast.error(error.response.data.message);
        }
    }

    useEffect(() => {
        const fetchSingleJob = async () => {
            try {
                const res = await axios.get(`${JOB_API_END_POINT}/get/${jobId}`,{withCredentials:true});
                if(res.data.success){
                    dispatch(setSingleJob(res.data.job));
                    setIsApplied(res.data.job.applications.some(application=>application.applicant === user?._id))
                }
            } catch (error) {
                console.log(error);
            }
        }
        fetchSingleJob();
      },[jobId, dispatch, user?._id]);

  return (
    <div className='max-w-7xl mx-20 my-10 '>
        <div className='flex items-center justify-between'>
            <div>
                <h1 className='font-bold text-xl'>{singleJob?.title}</h1>
                <div className='flex items-center gap-2 mt-4'>
                    <Badge className={'text-[#F83002] font-bold border-none'} variant="ghost">{singleJob?.position} Positions</Badge>
                    <Badge className={'text-blue-700 font-bold border-none'} variant="ghost">{singleJob?.jobType}</Badge>
                    <Badge className={'text-[#7209b7] font-bold border-none'} variant="ghost">{singleJob?.salary} LPA</Badge>
                </div>
            </div>
            <Button 
            onClick={isApplied ? null : applyJobHandler}
            disabled={isApplied} 
            className={`rounded-lg ${isApplied ? 'bg-gray-600 text-white cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-500 cursor-pointer'}`}>
                {isApplied ? 'Already applied' : 'Appliy Now'}
            </Button>
        </div>
        <h1 className='border-b-2 border-b-gray-300 font-medium py-5'>Job Description</h1>
        <div className='my-5'>
            <h1 className='my-1 font-bold'>Role: <span className='pl-4 font-normal text-gray-800'>{singleJob?.title}</span></h1>
            <h1 className='my-1 font-bold'>Location: <span className='pl-4 font-normal text-gray-800'>{singleJob?.location}</span></h1>
            <h1 className='my-1 font-bold'>Description: <span className='pl-4 font-normal text-gray-800'>{singleJob?.description}</span></h1>
            <h1 className='my-1 font-bold'>Experiense: <span className='pl-4 font-normal text-gray-800'>{singleJob?.experience} yrs</span></h1>
            <h1 className='my-1 font-bold'>Selery: <span className='pl-4 font-normal text-gray-800'>{singleJob?.salary} LPA</span></h1>
            <h1 className='my-1 font-bold'>Total Applicants: <span className='pl-4 font-normal text-gray-800'>{singleJob?.applications?.length}</span></h1>
            <h1 className='my-1 font-bold'>Posted Date: <span className='pl-4 font-normal text-gray-800'>{singleJob?.createdAt.split("T")[0]}</span></h1>
        </div>
    </div>
  )
}

export default JobDescription
